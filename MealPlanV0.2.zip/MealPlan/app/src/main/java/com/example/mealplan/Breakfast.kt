package com.example.mealplan

import android.os.Bundle
import android.widget.AdapterView.OnItemClickListener
import android.widget.ArrayAdapter
import android.widget.ListView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.app.AlertDialog
import android.content.Intent

import android.widget.EditText
import android.content.Context
import android.content.SharedPreferences.Editor
import androidx.core.content.edit

import android.widget.Button
public class Breakfast : AppCompatActivity() {


    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_breakfast)


val listView = findViewById<ListView>(R.id.listview1)

        var names = arrayOf("Calorie 1600", "Calorie 2000")
        var food1 = arrayOf("Chicken adobo", "Hotdog", )

        var arrayAdapter: ArrayAdapter<String> = ArrayAdapter(
           this,  android.R.layout.simple_list_item_1, names
        )



        // Display the item name when the item's row is clicked


        listView.adapter= arrayAdapter
        listView.setOnItemClickListener { adapterView, view, i, l ->
            Toast.makeText(this, "Item Selected "+ names[i], Toast.LENGTH_LONG)
                .show()
        }

        val sendfood= findViewById<Button>(R.id.button1)
        sendfood.setOnClickListener {
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Select an option")

            // Add the first button
            builder.setPositiveButton("Option 1") { _, _ ->
                val intent = Intent(this, MealPlan1::class.java)
                intent.putExtra("myArray", food1)
                startActivity(intent)
            }

            // Add the second button
            builder.setNegativeButton("Option 2") { _, _ ->
                val intent = Intent(this, MealPlan2::class.java)
                intent.putExtra("selectedOption", names[1])
                startActivity(intent)
            }

            // Add the third button
            builder.setNeutralButton("Option 3") { _, _ ->
                val intent = Intent(this, MealPlan2::class.java)
                intent.putExtra("selectedOption", names[2])
                startActivity(intent)
            }

            builder.show()
        }


    }
}