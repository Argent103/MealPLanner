package com.example.mealplan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText
import android.widget.CheckBox
import android.text.method.HideReturnsTransformationMethod
import android.text.method.PasswordTransformationMethod
import android.content.Intent
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
private lateinit var emailEditText: EditText
private lateinit var passwordEditText: EditText
private lateinit var showPasswordCheckBox: CheckBox
private lateinit var loginButton: Button

class Login : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        val buttonClick = findViewById<Button>(R.id.CONFIRM2)
        buttonClick.setOnClickListener {
            val intent = Intent(this, RegistrationPage::class.java)
            startActivity(intent)
        }

        emailEditText = findViewById(R.id.Email)
        passwordEditText = findViewById(R.id.Password)
        showPasswordCheckBox = findViewById(R.id.checkBox1)
        loginButton = findViewById(R.id.CONFIRM)

        showPasswordCheckBox.setOnCheckedChangeListener { _, isChecked ->
            if (isChecked) {
                passwordEditText.transformationMethod = HideReturnsTransformationMethod.getInstance()
            } else {
                passwordEditText.transformationMethod = PasswordTransformationMethod.getInstance()
            }
        }

        loginButton.setOnClickListener {
            val email = emailEditText.text.toString()
            val password = passwordEditText.text.toString()

            if (email.isNotEmpty() && password.isNotEmpty()) {
                FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
                    .addOnCompleteListener(this) { task ->
                        if (task.isSuccessful) {
                            // Login successful, sned in the main menu activity
                            val intent = Intent(this, MainMenu::class.java)
                            startActivity(intent)
                        } else {
                            // Login failed, add an error message here in the future
                        }
                    }
            }
        }
    }
}