package com.example.mealplan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class  MainMenu : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main_menu)



        val buttonClick = findViewById<Button>(R.id.mealButton1)
        buttonClick.setOnClickListener {
            val intent = Intent(this, ChooseMealPlan::class.java)
            startActivity(intent)
        }


        val buttonClick1 = findViewById<Button>(R.id.WeightButton)
        buttonClick1.setOnClickListener {
            val intent2 = Intent(this, WeightCompare::class.java)
            startActivity(intent2)
        }
    }
}