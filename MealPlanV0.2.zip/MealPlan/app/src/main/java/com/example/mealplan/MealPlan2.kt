package com.example.mealplan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.ListView
import android.widget.Button
import android.widget.EditText
import android.content.Context
import android.content.SharedPreferences.Editor
import androidx.core.content.edit

public class MealPlan2 : AppCompatActivity() {

    private lateinit var mealList1: ListView
    private lateinit var mealInput1: EditText
    //array that holds stuff








    private var meals1 = ArrayList<String>()  // Hold the meals of the meal plans
    private lateinit var mealAdapter1: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_plan2)


        var receivedArray1 = intent.getStringArrayExtra("myArray1") ?: emptyArray()
        var names11 = arrayOf("")
        names11 = receivedArray1.copyOf()
// calling the id of the listview and the text input
        mealList1 = findViewById(R.id.listview1)
        mealInput1 = findViewById(R.id.Holder1)


//getSharedPreference to save the contents of the list
        val preferences1 = getSharedPreferences("MealPreferences1", Context.MODE_PRIVATE)
        val mealSet1 = preferences1.getStringSet("Meals1", null)


        // transfer contents of the array names to meals


        meals1 = arrayListOf(*names11)

        //the code responsible for adding the meal
        mealSet1?.let { //add the contents of meals
            meals1.addAll(it)
        }

        mealAdapter1 = ArrayAdapter(this, android.R.layout.simple_list_item_1, meals1)
        mealList1.adapter = mealAdapter1

        val addMealButton = findViewById<Button>(R.id.addButton1)
        addMealButton.setOnClickListener {
            val meal = mealInput1.text.toString()
            if (meal.isNotEmpty()) {
                meals1.add(meal)
                mealAdapter1.notifyDataSetChanged()
                mealInput1.text.clear()
                preferences1.edit {
                    putStringSet("Meals1", meals1.toSet())
                }
            }
        }

        mealList1.setOnItemLongClickListener { _, _, position, _ ->
            meals1.removeAt(position)
            mealAdapter1.notifyDataSetChanged()
            preferences1.edit {
                putStringSet("Meals1", meals1.toSet())
            }
            true
        }
    }
}