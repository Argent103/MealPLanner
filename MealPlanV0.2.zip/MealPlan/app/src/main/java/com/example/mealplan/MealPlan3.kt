package com.example.mealplan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import android.widget.ListView
import android.widget.Button
import android.widget.EditText
import android.content.Context
import android.content.SharedPreferences.Editor
import androidx.core.content.edit

public class MealPlan3 : AppCompatActivity() {

    private lateinit var mealList2: ListView
    private lateinit var mealInput2: EditText
    //array that holds stuff








    private var meals2 = ArrayList<String>()  // Hold the meals of the meal plans
    private lateinit var mealAdapter2: ArrayAdapter<String>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_meal_plan3)


        var receivedArray2 = intent.getStringArrayExtra("myArray2") ?: emptyArray()
        var names12 = arrayOf("")
        names12 = receivedArray2.copyOf()
// calling the id of the listview and the text input
        mealList2 = findViewById(R.id.listview2)
        mealInput2 = findViewById(R.id.Holder2)


//getSharedPreference to save the contents of the list
        val preferences2 = getSharedPreferences("MealPreferences2", Context.MODE_PRIVATE)
        val mealSet2 = preferences2.getStringSet("Meals2", null)


        // transfer contents of the array names to meals


        meals2 = arrayListOf(*names12)

        //the code responsible for adding the meal
        mealSet2?.let { //add the contents of meals
            meals2.addAll(it)
        }

        mealAdapter2 = ArrayAdapter(this, android.R.layout.simple_list_item_1, meals2)
        mealList2.adapter = mealAdapter2

        val addMealButton = findViewById<Button>(R.id.addButton2)
        addMealButton.setOnClickListener {
            val meal = mealInput2.text.toString()
            if (meal.isNotEmpty()) {
                meals2.add(meal)
                mealAdapter2.notifyDataSetChanged()
                mealInput2.text.clear()
                preferences2.edit {
                    putStringSet("Meals1", meals2.toSet())
                }
            }
        }

        mealList2.setOnItemLongClickListener { _, _, position, _ ->
            meals2.removeAt(position)
            mealAdapter2.notifyDataSetChanged()
            preferences2.edit {
                putStringSet("Meals2", meals2.toSet())
            }
            true
        }
    }
}