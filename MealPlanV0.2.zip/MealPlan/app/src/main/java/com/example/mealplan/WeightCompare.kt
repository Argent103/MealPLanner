package com.example.mealplan

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import android.widget.EditText

class WeightCompare : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weight_compare)
        val buttonClick = findViewById<Button>(R.id.progress)
        buttonClick.setOnClickListener {
            val intent = Intent(this, Chart::class.java)
            startActivity(intent)
        }


//arrays
        val values = arrayOf("32KG", "46KG", "11KG", "67KG")
        val lastIndex = values.last()
        val inputText = findViewById<EditText>(R.id.input_text)
        val compareButton = findViewById<Button>(R.id.compare_button)
        val resultText = findViewById<TextView>(R.id.result_text)
        val resultText2 = findViewById<TextView>(R.id.result_text2)
        var string1: String = ""






        compareButton.setOnClickListener {
            val input = inputText.text.toString()
            val latestValue = values.lastOrNull()

           string1 = input
            // convert contents string to int



                resultText.text = "$lastIndex is your last recorded weight, $input is your latest weight. you have lost KG of weight"

        }











    }
}