package com.example.mealplan

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.graphics.Color

import com.github.mikephil.charting.charts.LineChart
import com.github.mikephil.charting.data.Entry
import com.github.mikephil.charting.data.LineData
import com.github.mikephil.charting.data.LineDataSet
class Chart : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chart)

        val lineChart = findViewById<LineChart>(R.id.line_chart)
        lineChart.setTouchEnabled(true)
        lineChart.setPinchZoom(true)

        val entries = ArrayList<Entry>()
        val data = arrayOf(12f, 32f, 43f, 21f, 61f, 32f, 21f)
        for (i in data.indices) {
            entries.add(Entry(i.toFloat(), data[i]))
        }

        val dataSet = LineDataSet(entries, "My Data")
        dataSet.color = Color.BLUE
        dataSet.valueTextColor = Color.RED

        val lineData = LineData(dataSet)
        lineChart.data = lineData

        lineChart.invalidate()
    }
}